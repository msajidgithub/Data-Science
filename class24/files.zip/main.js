// Mobile menu
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');
if (menuToggle) {
  menuToggle.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    navLinks.style.display = navLinks.classList.contains('open') ? 'flex' : '';
  });
}

// Scroll reveal
const revealEls = document.querySelectorAll('.reveal');
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
}, { threshold: 0.15 });
revealEls.forEach(el => io.observe(el));

// Hero orbit canvas — nodes representing the six services orbiting a central core
const canvas = document.getElementById('orbitCanvas');
if (canvas) {
  const ctx = canvas.getContext('2d');
  let w, h, dpr = Math.min(window.devicePixelRatio || 1, 2);

  function resize() {
    const rect = canvas.getBoundingClientRect();
    w = rect.width; h = rect.height;
    canvas.width = w * dpr; canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  window.addEventListener('resize', resize);
  resize();

  const labels = ['Design', 'Marketing', 'Web', 'UI/UX', 'Store', 'App'];
  const nodes = labels.map((label, i) => ({
    label,
    angle: (i / labels.length) * Math.PI * 2,
    radiusFactor: 0.38,
    speed: 0.0016 + (i % 2 === 0 ? 0.0004 : -0.0003)
  }));

  function draw(t) {
    ctx.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    const R = Math.min(w, h) * 0.38;

    // orbit rings
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    [0.38, 0.62].forEach(f => {
      ctx.beginPath();
      ctx.arc(cx, cy, Math.min(w, h) * f, 0, Math.PI * 2);
      ctx.stroke();
    });

    // core
    const coreR = Math.min(w, h) * 0.09;
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR * 2.2);
    grad.addColorStop(0, 'rgba(139,124,246,0.9)');
    grad.addColorStop(1, 'rgba(91,110,245,0)');
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(cx, cy, coreR * 2.2, 0, Math.PI * 2); ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath(); ctx.arc(cx, cy, coreR * 0.55, 0, Math.PI * 2); ctx.fill();

    const positions = [];
    nodes.forEach(n => {
      const angle = n.angle + t * n.speed;
      const x = cx + Math.cos(angle) * R;
      const y = cy + Math.sin(angle) * R * 0.62;
      positions.push({ x, y, label: n.label });
    });

    // connecting lines to core
    positions.forEach(p => {
      ctx.strokeStyle = 'rgba(139,124,246,0.25)';
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
    });

    // nodes
    positions.forEach(p => {
      const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 22);
      g.addColorStop(0, 'rgba(91,110,245,0.9)');
      g.addColorStop(1, 'rgba(91,110,245,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(p.x, p.y, 22, 0, Math.PI * 2); ctx.fill();

      ctx.fillStyle = '#0a0c16';
      ctx.beginPath(); ctx.arc(p.x, p.y, 7, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#8b7cf6';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.fillStyle = 'rgba(244,245,251,0.75)';
      ctx.font = '11px "IBM Plex Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(p.label, p.x, p.y - 14);
    });

    requestAnimationFrame(draw);
  }

  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReduced) {
    draw(0);
  } else {
    requestAnimationFrame(draw);
  }
}

// Forms — front-end only demo handling
document.querySelectorAll('form[data-demo-form]').forEach(form => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    const original = btn.textContent;
    btn.textContent = 'Sent — we\u2019ll be in touch';
    btn.style.opacity = '0.8';
    setTimeout(() => { btn.textContent = original; btn.style.opacity = '1'; form.reset(); }, 2400);
  });
});
